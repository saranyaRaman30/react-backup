import React, { Component } from 'react';
import './css/popup.css';
import close from './assests/close.png';
import shoppingbag from './assests/shopping-bags.svg'

class Popup extends Component {
  constructor() {
    super();
    this.currentval = React.createRef();
    this.state = {
      presentvalue: 0,
      isaddtobag:false,
      value: '0',
     
    }
   
  }
  componentDidMount() {
    if(this.props.selectedPizza){
      alert("sai"+this.props.cartdata);
      this.setState({     
        isaddtobag: true,
        value:1
      });
      // this.currentval.current.value;
    }
  }
  inputChangedHandler = (event) => {
    const updatedKeyword = event.target.value;
    // May be call for search result
}
  decrement(){
  //  var decrementedval = this.currentval.current.value - 1
  if(this.state.value > 0){
  var decrementedval = this.state.value - 1
   this.setState({     
    value: decrementedval
  });
  }
}
  increment(){
    var incrementedval = this.state.value + 1
    this.setState({
      value: incrementedval
    });  

  }
  render() {
    const { presentvalue} = this.state;
    return (
      <div className='Popup_container'>
        <div className='popup' >  
          <div className='popup_inner'>
            <span className="mycart"> My cart</span>      
          <img src={close} className="close" alt="close" width="30" onClick={this.props.closePopup}/>
          <hr></hr>
          {this.state.isaddtobag != true ?  
          <div className="empty-content">
            <img src={shoppingbag} className="shoppingbag" alt="logo" />
            <p>Your cart is empty</p>
            <span className="green-text">But it does not have to be.</span>
          </div>
          : <div className="popup_content">   
          {
             this.props.cartdata.map(cartItem => (
              <div key={cartItem.path}>
              <h1>sai {cartItem.name}</h1>
              <img src={cartItem.path} width="100"></img>
              </div>
            
            ))
          }
             
              <div className="quantity">
                <button className="minus_icon" onClick={this.decrement.bind(this)}> – </button>
                <div className="total_value"><input type="text" value={this.state.value} className="total_value_text" ref={this.currentval}  onChange={(event)=>this.inputChangedHandler(event)} /></div>
                <button className="plus_icon"  onClick={this.increment.bind(this)}> + </button>
              </div>
           </div>
          }  
          </div>  
        </div> 
      </div>
    );
  }
}

export default Popup;
