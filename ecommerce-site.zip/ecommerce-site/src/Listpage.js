import React, { Component } from 'react'
import './css/listpage.css';
import Header from './Header';
import data from './Jsondata';
import Popup from './Popup';

class Listpage extends Component {

  constructor() {
    super();
    this.buttonval1 = React.createRef();
    this.buttonval2 = React.createRef();
    this.buttonval3 = React.createRef();
    this.buttonval4 = React.createRef();
    this.filterChange = this.filterChange.bind(this);
    this.state = {
      displayCategory: "all",
      showPopup: false,
      productName:'',
      cart:[]
    }

  }
  componentDidMount() {

  }
  filterChange(e) {
    this.setState({
      displayCategory: e.currentTarget.value
    });
  }
  addtocart(prdtname,path) {
    this.setState(
      {  showPopup: true,productName:prdtname,imgPath:path }
      // () =>alert("sai"+this.state.productName)
    )
    // this.setState(state => {
    //   const { cart } = this.state;
    //   this.setState({ cart: [...cart] }, () => {
    //     //call back function of set state
    //     console.log(this.state.cart)
    //   });
    // });

    const updateCart = this.state.cart.map(data => {
     
        return data;
     
    });

      updateCart.push({
        name: prdtname,        
        path: path
      });

    this.setState({
      cart: updateCart
    });

  }
  openPopup() {
    this.setState({
      showPopup: !this.state.showPopup
    });
  }

  render() {
    const { type, displayCategory,productName } = this.state;
    return (
      <div className="Pizzalistpage">
        <Header></Header>
        <div className="Listpage-container">
          <div className="filter_pizzatype">
            <button value="all" ref={this.buttonval3} onClick={this.filterChange.bind(this)} >All</button>
            <button value="veg" ref={this.buttonval1} onClick={this.filterChange.bind(this)} >Veg</button>
            <button value="nonveg" ref={this.buttonval2} onClick={this.filterChange.bind(this)} >Non-veg</button>
            <button value="beverage" ref={this.buttonval4} onClick={this.filterChange.bind(this)} >Beverages</button>

          </div>
          {
            data.filter(
              ({ type }) =>
                displayCategory === type || displayCategory === "all"
            )
              .map(({ path, name, desc, id }) => {
                return (
                  <div className="pizzalist" key={id} >
                    <img src={path} width="260"></img>
                    <div className="pizza_details">
                      <h1>{name}</h1>
                      <p>{desc}</p>
                      <select className="pizza_size">
                        <option>Regular</option>
                        <option>Medium</option>
                        <option>Large</option>
                      </select>
                      <button className="addtocart" onClick={this.addtocart.bind(this,name,path)}>Add To Cart</button>
                    </div>
                  </div>
                )
              })}

        </div>
        {this.state.showPopup ?
          <Popup selectedPizza={this.state.productName} cartdata ={this.state.cart} closePopup={this.openPopup.bind(this)} ></Popup>
          : null
        }
      </div>
    );
  }

}

export default Listpage;
